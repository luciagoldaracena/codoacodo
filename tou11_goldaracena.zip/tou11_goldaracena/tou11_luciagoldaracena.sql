create database tou11;

use tou11;

create table clientes(
id int(11) not null auto_increment,
nombre varchar(40) not null collate latin1_swedish_ci,
apellido varchar(40) not null collate latin1_swedish_ci,
edad tinyint(2) not null, 
fecha timestamp not null default current_timestamp,
provincia varchar(30) not null collate latin1_swedish_ci,
primary key(id)
);

insert into clientes values (1,"Santiago","Nasar",21,null,"Buenos Aires");
insert into clientes values (2,"Ángela","Vicario",19,null,"Catamarca");
insert into clientes values (3,"Bayardo","San Román",30,null,"Chaco");
insert into clientes values (4,"Ibrahim","Nasar",56,null,"Chubut");
insert into clientes values (5,"Victoria","Guzmán",48,null,"Chaco");




